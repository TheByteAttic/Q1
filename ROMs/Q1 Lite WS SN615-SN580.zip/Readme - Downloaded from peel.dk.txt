ROM files from Q1 Lite SN615 (Not correct SN number, its a combination unit of SN 615 and SN 580)

More information at www.peeldk/Q1

